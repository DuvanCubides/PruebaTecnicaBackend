﻿namespace Backend.Model
{
    public class CoursesModel
    {
        public int id { get; set; }
        public string nameCourse { get; set; }
        public int idTeacher { get; set; }
    }
}

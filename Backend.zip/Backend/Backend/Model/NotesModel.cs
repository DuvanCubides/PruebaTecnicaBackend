﻿namespace Backend.Model
{
    public class NotesModel
    {
        public int id { get; set; }
        public double Note { get; set; }
        public int idCourse { get; set; }
    }
}
